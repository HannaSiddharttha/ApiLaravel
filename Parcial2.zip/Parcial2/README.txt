Instrucciones para correr la Api

Descargar toda la carpeta del repositorio de Git:
https://github.com/HannaSiddharttha/ApiLaravel.git

Primero descargar el compose en el siguiente link:
https://getcomposer.org/

Importar la base de datos

Agregar codigo a tu ambiente de desarrollo

Definir las conexiones correspondientes en el archivo .env ubicado en la raiz del proyecto.

Iniciar servidor y acceder al proyecto en la carpeta "public", ejemplo: localhost/{nombre del proyecto}/public.

Desde esa ubicación se pueden hacer pruebas, por ejemplo localhost/{nombre de proyecto}/public/api/product retornará
una lista de productos.

De igual manera para probar en Postman se tendria que poner 127.0.0.1/{nombre del proyecto}/public.